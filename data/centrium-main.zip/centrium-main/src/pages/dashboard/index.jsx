import { lazy } from 'react';
import { Outlet, Route, Routes } from 'react-router-dom';
import AdminRouteWrapper from '@/components/AdminRouteWrapper';

const Ecommerce = lazy(() => import('./Ecommerce'));
const Analytics = lazy(() => import('./Analytics'));
const Project = lazy(() => import('./Project'));
const CRM = lazy(() => import('./CRM'));
const EWallet = lazy(() => import('./E-Wallet'));
const Admin = lazy(() => import('./Admin'));
const TradingList = lazy(() => import('@/pages/admin/Trading/TradingList'));
const TradeDetail = lazy(() => import('@/pages/admin/Trading/TradeDetail'));

export default function Dashboard() {
    return (
        <Routes>
            <Route path="/*" element={<Outlet />}>
                <Route index element={<Ecommerce />} />
                <Route path="analytics" element={<Analytics />} />
                <Route path="ecommerce" element={<Ecommerce />} />
                <Route path="project" element={<Project />} />
                <Route path="crm" element={<CRM />} />
                <Route path="e-wallet" element={<EWallet />} />
                <Route path="admin" element={
                    <AdminRouteWrapper>
                        <Admin />
                    </AdminRouteWrapper>
                } />
                <Route path="trading" element={
                    <AdminRouteWrapper>
                        <TradingList />
                    </AdminRouteWrapper>
                } />
                <Route path="trading/details/:tradeId" element={
                    <AdminRouteWrapper>
                        <TradeDetail />
                    </AdminRouteWrapper>
                } />
            </Route>
        </Routes>
    );
}