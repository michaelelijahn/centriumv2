import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Table, Badge, Spinner } from 'react-bootstrap';
import { Link, Navigate } from 'react-router-dom';
import { authApi } from '@/common';
import { useNotificationContext, useAuthContext } from '@/common';
import { PageBreadcrumb } from '@/components';

const AdminDashboard = () => {
    const [ticketStats, setTicketStats] = useState({
        total: 0,
        open: 0,
        in_progress: 0,
        resolved: 0,
        closed: 0
    });
    const [userStats, setUserStats] = useState({
        total: 0,
        active: 0,
        inactive: 0,
        admin: 0
    });
    const [recentTickets, setRecentTickets] = useState([]);
    const [loading, setLoading] = useState(true);
    const { showNotification } = useNotificationContext();
    const { user } = useAuthContext();

    if (user && user.role !== 'admin') {
        return <Navigate to="/" replace />;
    }

    useEffect(() => {
        fetchDashboardData();
    }, []);

    const fetchDashboardData = async () => {
        setLoading(true);
        try {
            // Get recent tickets with counts by status
            const ticketsResponse = await authApi.getAllTickets({
                limit: 5,
                sort_by: 'created_at',
                sort_order: 'desc'
            });
            
            if (ticketsResponse?.data) {
                setRecentTickets(ticketsResponse.data.tickets || []);
                
                // Extract ticket statistics if available
                const stats = ticketsResponse.data.statistics || {};
                setTicketStats({
                    total: stats.total || 0,
                    open: stats.open || 0,
                    in_progress: stats.in_progress || 0,
                    resolved: stats.resolved || 0,
                    closed: stats.closed || 0
                });
            }
            
            // Get user statistics
            const usersResponse = await authApi.getAllUsers({
                limit: 1,  // Just need counts, not actual users
                statistics: true
            });

            console.log("get all users result: ", usersResponse);
            
            if (usersResponse?.data?.statistics) {
                const stats = usersResponse.data.statistics;
                setUserStats({
                    total: stats.total || 0,
                    active: stats.active || 0,
                    inactive: stats.inactive || 0,
                    admin: stats.admin || 0
                });
            }
        } catch (error) {
            showNotification({
                message: `Error loading dashboard data: ${error.toString()}`,
                type: 'error'
            });
        } finally {
            setLoading(false);
        }
    };

    const getStatusBadge = (status) => {
        switch (status) {
            case 'open':
                return <Badge bg="info">Open</Badge>;
            case 'in_progress':
                return <Badge bg="warning">In Progress</Badge>;
            case 'resolved':
                return <Badge bg="success">Resolved</Badge>;
            case 'closed':
                return <Badge bg="secondary">Closed</Badge>;
            default:
                return <Badge bg="light" text="dark">{status}</Badge>;
        }
    };

    return (
        <>
            <PageBreadcrumb title="Admin Dashboard" subName="Admin" />
            
            {/* Stats Cards */}
            <Row>
                <Col xl={3} md={6} className="mb-4">
                    <Card className="bg-primary text-white h-100">
                        <Card.Body>
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 className="text-white">Total Users</h5>
                                    <h2 className="my-2 text-white">{userStats.total}</h2>
                                    <p className="mb-0">{userStats.active} active users</p>
                                </div>
                                <div className="avatar-lg rounded-circle bg-white bg-opacity-25 d-flex align-items-center justify-content-center">
                                    <i className="mdi mdi-account-group mdi-36px text-white"></i>
                                </div>
                            </div>
                            <Link to="/admin/users" className="text-white">
                                <div className="d-flex align-items-center mt-4 pt-2 border-top border-white border-opacity-50">
                                    <span className="flex-grow-1">View Details</span>
                                    <i className="mdi mdi-arrow-right"></i>
                                </div>
                            </Link>
                        </Card.Body>
                    </Card>
                </Col>
                
                <Col xl={3} md={6} className="mb-4">
                    <Card className="bg-success text-white h-100">
                        <Card.Body>
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 className="text-white">Total Tickets</h5>
                                    <h2 className="my-2 text-white">{ticketStats.total}</h2>
                                    <p className="mb-0">{ticketStats.open} open tickets</p>
                                </div>
                                <div className="avatar-lg rounded-circle bg-white bg-opacity-25 d-flex align-items-center justify-content-center">
                                    <i className="mdi mdi-ticket mdi-36px text-white"></i>
                                </div>
                            </div>
                            <Link to="/admin/tickets" className="text-white">
                                <div className="d-flex align-items-center mt-4 pt-2 border-top border-white border-opacity-50">
                                    <span className="flex-grow-1">View Details</span>
                                    <i className="mdi mdi-arrow-right"></i>
                                </div>
                            </Link>
                        </Card.Body>
                    </Card>
                </Col>
                
                <Col xl={3} md={6} className="mb-4">
                    <Card className="bg-warning text-white h-100">
                        <Card.Body>
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 className="text-white">In Progress</h5>
                                    <h2 className="my-2 text-white">{ticketStats.in_progress}</h2>
                                    <p className="mb-0">Tickets being processed</p>
                                </div>
                                <div className="avatar-lg rounded-circle bg-white bg-opacity-25 d-flex align-items-center justify-content-center">
                                    <i className="mdi mdi-clock-fast mdi-36px text-white"></i>
                                </div>
                            </div>
                            <Link to="/admin/tickets?status=in_progress" className="text-white">
                                <div className="d-flex align-items-center mt-4 pt-2 border-top border-white border-opacity-50">
                                    <span className="flex-grow-1">View Details</span>
                                    <i className="mdi mdi-arrow-right"></i>
                                </div>
                            </Link>
                        </Card.Body>
                    </Card>
                </Col>
                
                <Col xl={3} md={6} className="mb-4">
                    <Card className="bg-info text-white h-100">
                        <Card.Body>
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 className="text-white">Open Tickets</h5>
                                    <h2 className="my-2 text-white">{ticketStats.open}</h2>
                                    <p className="mb-0">Need your attention</p>
                                </div>
                                <div className="avatar-lg rounded-circle bg-white bg-opacity-25 d-flex align-items-center justify-content-center">
                                    <i className="mdi mdi-alert-circle-outline mdi-36px text-white"></i>
                                </div>
                            </div>
                            <Link to="/admin/tickets?status=open" className="text-white">
                                <div className="d-flex align-items-center mt-4 pt-2 border-top border-white border-opacity-50">
                                    <span className="flex-grow-1">View Details</span>
                                    <i className="mdi mdi-arrow-right"></i>
                                </div>
                            </Link>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            
            {/* Recent Tickets Table */}
            <Row>
                <Col>
                    <Card>
                        <Card.Header className="d-flex justify-content-between align-items-center">
                            <h4 className="m-0">Recent Support Tickets</h4>
                            <Link to="/admin/tickets" className="btn btn-primary btn-sm">
                                View All
                            </Link>
                        </Card.Header>
                        <Card.Body>
                            {loading ? (
                                <div className="text-center py-3">
                                    <Spinner animation="border" variant="primary" />
                                    <p className="mt-2">Loading dashboard data...</p>
                                </div>
                            ) : (
                                <div className="table-responsive">
                                    <Table className="table-centered table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Subject</th>
                                                <th>User</th>
                                                <th>Status</th>
                                                <th>Created</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {recentTickets.length === 0 ? (
                                                <tr>
                                                    <td colSpan="6" className="text-center">
                                                        No tickets found.
                                                    </td>
                                                </tr>
                                            ) : (
                                                recentTickets.map((ticket) => (
                                                    <tr key={ticket.id}>
                                                        <td>#{ticket.id}</td>
                                                        <td className="text-truncate" style={{ maxWidth: '200px' }}>
                                                            <Link to={`/admin/tickets/${ticket.id}`}>
                                                                {ticket.subject}
                                                            </Link>
                                                        </td>
                                                        <td>
                                                            <Link to={`/admin/users/${ticket.customer.id}`}>
                                                                {ticket.customer.name}
                                                            </Link>
                                                        </td>
                                                        <td>{getStatusBadge(ticket.status)}</td>
                                                        <td>{ticket.created_at}</td>
                                                        <td>
                                                            <Link to={`/admin/tickets/${ticket.id}`} className="btn btn-sm btn-primary">
                                                                <i className="mdi mdi-eye me-1"></i>
                                                                View
                                                            </Link>
                                                        </td>
                                                    </tr>
                                                ))
                                            )}
                                        </tbody>
                                    </Table>
                                </div>
                            )}
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </>
    );
};

export default AdminDashboard;