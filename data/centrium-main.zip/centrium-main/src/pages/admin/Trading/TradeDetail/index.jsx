import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Row, Col, Table, Button, Spinner, Badge } from 'react-bootstrap';
import { authApi } from '@/common';
import { useNotificationContext, useAuthContext } from '@/common';
import { PageBreadcrumb } from '@/components';

const TradeDetail = () => {
    const { tradeId } = useParams();
    const navigate = useNavigate();
    const [trade, setTrade] = useState(null);
    const [loading, setLoading] = useState(true);
    const { showNotification } = useNotificationContext();
    const { user } = useAuthContext();

    useEffect(() => {
        if (user?.role !== 'admin') {
            showNotification({
                message: 'You do not have permission to access this page',
                type: 'error'
            });
            navigate('/');
            return;
        }
        fetchTradeDetails();
    }, [tradeId]);

    const fetchTradeDetails = async () => {
        setLoading(true);
        try {
            const response = await authApi.getTradeById(tradeId);
            
            if (response?.data) {
                setTrade(response.data);
            }
        } catch (error) {
            showNotification({
                message: `Error fetching trade details: ${error.toString()}`,
                type: 'error'
            });
        } finally {
            setLoading(false);
        }
    };

    const formatSide = (side) => {
        if (!side) return '-';
        return side.toLowerCase() === 'buy' 
            ? <Badge bg="success">Buy</Badge>
            : <Badge bg="danger">Sell</Badge>;
    };

    const formatDate = (dateStr) => {
        if (!dateStr) return '-';
        
        if (dateStr.includes('T')) {
            const date = new Date(dateStr);
            return date.toLocaleString();
        }
        
        return dateStr;
    };

    const formatValue = (val) => {
        if (val === undefined || val === null || val === '') return '-';
        return val;
    };

    const formatNumber = (num) => {
        if (num === undefined || num === null || num === '') return '-';
        return parseFloat(num).toLocaleString();
    };

    if (loading) {
        return (
            <>
                <PageBreadcrumb title="Trade Details" subName="Admin Trading" />
                <div className="text-center p-5">
                    <Spinner animation="border" variant="primary" />
                    <p className="mt-2">Loading trade details...</p>
                </div>
            </>
        );
    }

    if (!trade) {
        return (
            <>
                <PageBreadcrumb title="Trade Details" subName="Admin Trading" />
                <Card>
                    <Card.Body className="text-center p-5">
                        <i className="mdi mdi-alert-circle-outline text-danger" style={{ fontSize: '48px' }}></i>
                        <h3 className="mt-2">Trade Not Found</h3>
                        <p>The trade you're looking for doesn't exist or you don't have permission to view it.</p>
                        <Button variant="primary" onClick={() => navigate('/admin/trading')}>
                            Back to Trading List
                        </Button>
                    </Card.Body>
                </Card>
            </>
        );
    }

    return (
        <>
            <PageBreadcrumb title="Trade Details" subName="Admin Trading" />
            
            <Card className="mb-4">
                <Card.Header className="d-flex justify-content-between align-items-center">
                    <h4 className="m-0">Trade #{trade.trade_id}</h4>
                    <Button variant="primary" onClick={() => navigate('/admin/trading')}>
                        <i className="mdi mdi-arrow-left me-1"></i> Back to List
                    </Button>
                </Card.Header>
                <Card.Body>
                    <Row className="g-3">
                        <Col md={6} lg={3}>
                            <Card className="bg-light">
                                <Card.Body className="p-3">
                                    <h6 className="text-muted mb-1">Trade ID</h6>
                                    <h5 className="mb-0">{formatValue(trade.trade_id)}</h5>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={6} lg={3}>
                            <Card className="bg-light">
                                <Card.Body className="p-3">
                                    <h6 className="text-muted mb-1">Date & Time</h6>
                                    <h5 className="mb-0">{formatDate(trade.timestamp)}</h5>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={6} lg={3}>
                            <Card className="bg-light">
                                <Card.Body className="p-3">
                                    <h6 className="text-muted mb-1">Side</h6>
                                    <h5 className="mb-0">{formatSide(trade.side)}</h5>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={6} lg={3}>
                            <Card className="bg-light">
                                <Card.Body className="p-3">
                                    <h6 className="text-muted mb-1">Currency Pair</h6>
                                    <h5 className="mb-0">{formatValue(trade.currency_pair)}</h5>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>

                    <Row className="mt-4">
                        <Col>
                            <h5 className="mb-3">Trade Information</h5>
                            <Table className="table-bordered">
                                <tbody>
                                    <tr>
                                        <th style={{width: '200px'}}>Amend ID</th>
                                        <td>{formatValue(trade.amend_id)}</td>
                                        <th style={{width: '200px'}}>Timestamp</th>
                                        <td>{formatDate(trade.timestamp)}</td>
                                    </tr>
                                    <tr>
                                        <th>Book</th>
                                        <td>{formatValue(trade.book)}</td>
                                        <th>Currency Pair</th>
                                        <td>{formatValue(trade.currency_pair)}</td>
                                    </tr>
                                    <tr>
                                        <th>Side (Base CCY)</th>
                                        <td>{formatSide(trade.side)}</td>
                                        <th>Quantity</th>
                                        <td>{formatNumber(trade.quantity)}</td>
                                    </tr>
                                    <tr>
                                        <th>Price</th>
                                        <td>{formatNumber(trade.price)}</td>
                                        <th>Margin Pips</th>
                                        <td>{formatNumber(trade.margin_pips)}</td>
                                    </tr>
                                    <tr>
                                        <th>Margin BPS</th>
                                        <td>{formatNumber(trade.margin_bps)}</td>
                                        <th>Markup</th>
                                        <td>{formatValue(trade.markup)}</td>
                                    </tr>
                                    <tr>
                                        <th>Market</th>
                                        <td>{formatValue(trade.market)}</td>
                                        <th>Dealt CCY</th>
                                        <td>{formatValue(trade.dealt_ccy)}</td>
                                    </tr>
                                    <tr>
                                        <th>Dealt Quantity</th>
                                        <td>{formatNumber(trade.dealt_quantity)}</td>
                                        <th>Value Date</th>
                                        <td>{formatValue(trade.value_date)}</td>
                                    </tr>
                                    <tr>
                                        <th>Trade Date</th>
                                        <td>{formatValue(trade.trade_date)}</td>
                                        <th>Trade ID</th>
                                        <td>{formatValue(trade.trade_id)}</td>
                                    </tr>
                                    <tr>
                                        <th>Order ID</th>
                                        <td>{formatValue(trade.order_id)}</td>
                                        <th>Counterparty</th>
                                        <td>{formatValue(trade.counterparty)}</td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Col>
                    </Row>

                    {trade.trade_details && (
                        <Row className="mt-4">
                            <Col>
                                <h5 className="mb-3">Additional Details</h5>
                                <div className="bg-light p-3 rounded">
                                    <pre style={{margin: 0}}>{trade.trade_details}</pre>
                                </div>
                            </Col>
                        </Row>
                    )}
                </Card.Body>
            </Card>
        </>
    );
};

export default TradeDetail;