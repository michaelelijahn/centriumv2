import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Spinner, Badge, Pagination, Row, Col, OverlayTrigger, Tooltip } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { authApi } from '@/common';
import { useNotificationContext, useAuthContext } from '@/common';
import { PageBreadcrumb } from '@/components';
import TradingFilters from './TradingFilters';
import CsvUploader from './CsvUploader';

const TradingList = () => {
    const [trades, setTrades] = useState([]);
    const [loading, setLoading] = useState(true);
    const [uploading, setUploading] = useState(false);
    const [stats, setStats] = useState({
        total: 0,
        buy: 0,
        sell: 0,
        currencies: {}
    });
    const [pagination, setPagination] = useState({
        page: 1,
        limit: 10,
        total: 0,
        pages: 0
    });
    const [filters, setFilters] = useState({
        search: '',
        side: '',
        book: '',
        currency_pair: '',
        counterparty: '',
        sort_by: 'timestamp',
        sort_order: 'desc',
        date_from: '',
        date_to: ''
    });
    const { showNotification } = useNotificationContext();
    const { user } = useAuthContext();

    useEffect(() => {
        if (user?.role !== 'admin') {
            showNotification({
                message: 'You do not have permission to access this page',
                type: 'error'
            });
            return;
        }
        fetchTrades();
    }, [pagination.page, filters]);

    const fetchTrades = async () => {
        setLoading(true);
        try {
            const queryParams = {
                page: pagination.page,
                limit: pagination.limit,
                ...filters
            };

            Object.keys(queryParams).forEach(key => {
                if (queryParams[key] === '') {
                    delete queryParams[key];
                }
            });

            const response = await authApi.getTrades(queryParams);
            
            if (response?.data) {
                setTrades(response.data.trades || []);
                setStats(response.data.statistics || {});
                setPagination({
                    ...pagination,
                    total: response.data.pagination.total,
                    pages: response.data.pagination.pages
                });
            }
        } catch (error) {
            showNotification({
                message: `Error fetching trades: ${error.toString()}`,
                type: 'error'
            });
        } finally {
            setLoading(false);
        }
    };

    const handleFilterChange = (newFilters) => {
        setFilters(newFilters);
        setPagination({ ...pagination, page: 1 });
    };

    const handleSortChange = (column) => {
        if (filters.sort_by === column) {
            setFilters({
                ...filters,
                sort_order: filters.sort_order === 'asc' ? 'desc' : 'asc'
            });
        } else {
            setFilters({
                ...filters,
                sort_by: column,
                sort_order: 'desc'
            });
        }
    };

    const getSortIcon = (column) => {
        if (filters.sort_by !== column) return null;
        
        return filters.sort_order === 'asc' 
            ? <i className="mdi mdi-arrow-up ms-1" />
            : <i className="mdi mdi-arrow-down ms-1" />;
    };

    const handlePageChange = (page) => {
        setPagination({
            ...pagination,
            page
        });
    };

    const handleFileUpload = async (file) => {
        setUploading(true);
        try {
            const formData = new FormData();
            formData.append('file', file);
            
            const response = await authApi.uploadTradesCsv(formData);
            
            if (response?.success) {
                showNotification({
                    message: `Successfully uploaded ${response.data.inserted} new trades`,
                    type: 'success'
                });
                fetchTrades();
            }
        } catch (error) {
            showNotification({
                message: `Error uploading file: ${error.toString()}`,
                type: 'error'
            });
        } finally {
            setUploading(false);
        }
    };

    const formatSide = (side) => {
        if (!side) return '-';
        const badge = side.toLowerCase() === 'buy' 
            ? <Badge bg="success">Buy</Badge>
            : <Badge bg="danger">Sell</Badge>;
        return badge;
    };
    
    const formatValue = (val) => {
        if (val === undefined || val === null || val === '') return '-';
        return val;
    };
    
    const formatNumber = (num) => {
        if (num === undefined || num === null || num === '') return '-';
        return parseFloat(num).toLocaleString();
    };
    
    const formatDate = (dateStr) => {
        if (!dateStr) return '-';
        if (!dateStr.includes('T')) {
            return dateStr;
        }
        const date = new Date(dateStr);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    };

    const formatPrice = (price) => {
        if (!price) return '-';
        return parseFloat(price).toFixed(5);
    };

    return (
        <>
            <PageBreadcrumb title="Trading Dashboard" subName="Admin" />
            
            <Row className="mb-4">
                <Col>
                    <Card>
                        <Card.Body>
                            <CsvUploader 
                                onUpload={handleFileUpload} 
                                uploading={uploading} 
                            />
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            
            <Card>
                <Card.Header>
                    <div className="d-flex justify-content-between align-items-center flex-wrap">
                        <h4 className="header-title mb-3 mb-sm-0">Trading List</h4>
                    </div>
                </Card.Header>
                <Card.Body>
                    <TradingFilters 
                        filters={filters} 
                        onFilterChange={handleFilterChange} 
                    />

                    {/* Statistics Cards */}
                    <Row className="mb-4">
                        <Col md={3} sm={6} className="mb-2 mb-md-0">
                            <Card className="border bg-light mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-primary rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-chart-timeline-variant text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {stats.total}
                                            </h5>
                                            <p className="text-muted mb-0">Total Trades</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                        
                        <Col md={3} sm={6} className="mb-2 mb-md-0">
                            <Card className="border bg-success bg-opacity-10 mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-success rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-arrow-up-bold text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {stats.buy || 0}
                                            </h5>
                                            <p className="text-muted mb-0">Buy Orders</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                        
                        <Col md={3} sm={6} className="mb-2 mb-md-0">
                            <Card className="border bg-danger bg-opacity-10 mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-danger rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-arrow-down-bold text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {stats.sell || 0}
                                            </h5>
                                            <p className="text-muted mb-0">Sell Orders</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                        
                        <Col md={3} sm={6}>
                            <Card className="border bg-info bg-opacity-10 mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-info rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-currency-usd text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {Object.keys(stats.currencies || {}).length}
                                            </h5>
                                            <p className="text-muted mb-0">Currency Pairs</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>

                    <div className="table-responsive">
                        <Table className="table-centered table-hover mb-0" style={{ minWidth: '1500px' }}>
                            <thead>
                                <tr>
                                    <th 
                                        onClick={() => handleSortChange('amend_id')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Amend ID {getSortIcon('amend_id')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('timestamp')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Timestamp {getSortIcon('timestamp')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('book')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Book {getSortIcon('book')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('currency_pair')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Currency Pair {getSortIcon('currency_pair')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('side')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Side {getSortIcon('side')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('quantity')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Quantity {getSortIcon('quantity')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('price')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Price {getSortIcon('price')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('margin_pips')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Margin Pips {getSortIcon('margin_pips')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('margin_bps')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Margin Bps {getSortIcon('margin_bps')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('markup')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Markup {getSortIcon('markup')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('market')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Market {getSortIcon('market')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('dealt_ccy')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Dealt CCY {getSortIcon('dealt_ccy')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('dealt_quantity')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Dealt Quantity {getSortIcon('dealt_quantity')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('value_date')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Value Date {getSortIcon('value_date')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('trade_details')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Trade Details {getSortIcon('trade_details')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('trade_date')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Trade Date {getSortIcon('trade_date')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('trade_id')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Trade ID {getSortIcon('trade_id')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('order_id')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Order ID {getSortIcon('order_id')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('counterparty')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Counterparty {getSortIcon('counterparty')}
                                    </th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {loading ? (
                                    <tr>
                                        <td colSpan="20" className="text-center py-3">
                                            <Spinner animation="border" size="sm" variant="primary" className="me-2" />
                                            Loading trades...
                                        </td>
                                    </tr>
                                ) : trades.length === 0 ? (
                                    <tr>
                                        <td colSpan="20" className="text-center py-3">
                                            No trades found. Use the upload function to add trades.
                                        </td>
                                    </tr>
                                ) : (
                                    trades.map((trade) => (
                                        <tr key={trade.trade_id}>
                                            <td>{formatValue(trade.amend_id)}</td>
                                            <td>{formatDate(trade.timestamp)}</td>
                                            <td>{formatValue(trade.book)}</td>
                                            <td>{formatValue(trade.currency_pair)}</td>
                                            <td>{formatSide(trade.side)}</td>
                                            <td>{formatNumber(trade.quantity)}</td>
                                            <td>{formatPrice(trade.price)}</td>
                                            <td>{formatNumber(trade.margin_pips)}</td>
                                            <td>{formatNumber(trade.margin_bps)}</td>
                                            <td>{formatValue(trade.markup)}</td>
                                            <td>{formatValue(trade.market)}</td>
                                            <td>{formatValue(trade.dealt_ccy)}</td>
                                            <td>{formatNumber(trade.dealt_quantity)}</td>
                                            <td>{formatValue(trade.value_date)}</td>
                                            <td>{formatValue(trade.trade_details)}</td>
                                            <td>{formatValue(trade.trade_date)}</td>
                                            <td>{formatValue(trade.trade_id)}</td>
                                            <td>{formatValue(trade.order_id)}</td>
                                            <td>{formatValue(trade.counterparty)}</td>
                                            <td>
                                                <OverlayTrigger
                                                    placement="left"
                                                    overlay={<Tooltip>View Details</Tooltip>}
                                                >
                                                    <Link 
                                                        to={`/admin/trading/details/${trade.trade_id}`} 
                                                        className="btn btn-sm btn-primary"
                                                    >
                                                        <i className="mdi mdi-eye"></i>
                                                    </Link>
                                                </OverlayTrigger>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </Table>
                    </div>

                    {pagination.pages > 1 && (
                        <div className="d-flex justify-content-center mt-4">
                            <Pagination>
                                <Pagination.First 
                                    disabled={pagination.page === 1}
                                    onClick={() => handlePageChange(1)}
                                />
                                <Pagination.Prev 
                                    disabled={pagination.page === 1}
                                    onClick={() => handlePageChange(pagination.page - 1)}
                                />
                                
                                {[...Array(pagination.pages)].map((_, i) => {
                                    if (
                                        i + 1 === 1 || 
                                        i + 1 === pagination.pages || 
                                        (i + 1 >= pagination.page - 2 && i + 1 <= pagination.page + 2)
                                    ) {
                                        return (
                                            <Pagination.Item
                                                key={i}
                                                active={i + 1 === pagination.page}
                                                onClick={() => handlePageChange(i + 1)}
                                            >
                                                {i + 1}
                                            </Pagination.Item>
                                        );
                                    } else if (
                                        i + 1 === pagination.page - 3 || 
                                        i + 1 === pagination.page + 3
                                    ) {
                                        return <Pagination.Ellipsis key={i} className="disabled" />;
                                    }
                                    
                                    return null;
                                })}
                                
                                <Pagination.Next 
                                    disabled={pagination.page === pagination.pages}
                                    onClick={() => handlePageChange(pagination.page + 1)}
                                />
                                <Pagination.Last 
                                    disabled={pagination.page === pagination.pages}
                                    onClick={() => handlePageChange(pagination.pages)}
                                />
                            </Pagination>
                        </div>
                    )}
                </Card.Body>
            </Card>
        </>
    );
};

export default TradingList;