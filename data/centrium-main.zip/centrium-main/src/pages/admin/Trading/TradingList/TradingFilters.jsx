import React, { useState, useEffect } from 'react';
import { Form, Button, Row, Col, InputGroup } from 'react-bootstrap';
import { authApi } from '@/common';

const TradingFilters = ({ filters, onFilterChange }) => {
    const [filterOptions, setFilterOptions] = useState({
        currencies: [],
        books: [],
        counterparties: []
    });
    const [localFilters, setLocalFilters] = useState({ ...filters });
    const [isExpanded, setIsExpanded] = useState(false);

    useEffect(() => {
        fetchFilterOptions();
    }, []);

    useEffect(() => {
        setLocalFilters({ ...filters });
    }, [filters]);

    const fetchFilterOptions = async () => {
        try {
            const response = await authApi.getTradeFilterOptions();
            
            if (response?.data) {
                setFilterOptions({
                    currencies: response.data.currencies || [],
                    books: response.data.books || [],
                    counterparties: response.data.counterparties || []
                });
            }
        } catch (error) {
            console.error('Error fetching filter options:', error);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setLocalFilters(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleReset = () => {
        const resetFilters = {
            search: '',
            side: '',
            book: '',
            currency_pair: '',
            counterparty: '',
            date_from: '',
            date_to: '',
            sort_by: 'timestamp',
            sort_order: 'desc'
        };
        setLocalFilters(resetFilters);
        onFilterChange(resetFilters);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onFilterChange(localFilters);
    };

    return (
        <div className="mb-4">
            <Form onSubmit={handleSubmit}>
                <Row className="align-items-end g-2 mb-3">
                    <Col sm={4} md={5} lg={6}>
                        <InputGroup>
                            <Form.Control
                                placeholder="Search by Trade ID, Amend ID, Order ID..."
                                name="search"
                                value={localFilters.search}
                                onChange={handleInputChange}
                            />
                            {localFilters.search && (
                                <Button 
                                    variant="outline-secondary" 
                                    onClick={() => {
                                        setLocalFilters(prev => ({ ...prev, search: '' }));
                                    }}
                                >
                                    <i className="mdi mdi-close"></i>
                                </Button>
                            )}
                        </InputGroup>
                    </Col>
                    <Col sm={3} md={2}>
                        <Form.Select 
                            name="side" 
                            value={localFilters.side}
                            onChange={handleInputChange}
                        >
                            <option value="">All Sides</option>
                            <option value="buy">Buy</option>
                            <option value="sell">Sell</option>
                        </Form.Select>
                    </Col>
                    <Col sm={5} md={5} lg={4}>
                        <div className="d-flex gap-2">
                            <Button type="submit" variant="primary" className="w-100">
                                <i className="mdi mdi-filter me-1"></i> Apply Filters
                            </Button>
                            <Button 
                                type="button" 
                                variant="light" 
                                onClick={handleReset}
                            >
                                <i className="mdi mdi-refresh"></i>
                            </Button>
                            <Button 
                                type="button" 
                                variant="light"
                                onClick={() => setIsExpanded(!isExpanded)}
                            >
                                <i className={`mdi mdi-chevron-${isExpanded ? 'up' : 'down'}`}></i>
                            </Button>
                        </div>
                    </Col>
                </Row>

                {isExpanded && (
                    <Row className="g-2">
                        <Col sm={6} md={3}>
                            <Form.Group>
                                <Form.Label>Book</Form.Label>
                                <Form.Select 
                                    name="book" 
                                    value={localFilters.book}
                                    onChange={handleInputChange}
                                >
                                    <option value="">All Books</option>
                                    {filterOptions.books.map((book, index) => (
                                        <option key={index} value={book}>{book}</option>
                                    ))}
                                </Form.Select>
                            </Form.Group>
                        </Col>
                        <Col sm={6} md={3}>
                            <Form.Group>
                                <Form.Label>Currency Pair</Form.Label>
                                <Form.Select 
                                    name="currency_pair" 
                                    value={localFilters.currency_pair}
                                    onChange={handleInputChange}
                                >
                                    <option value="">All Pairs</option>
                                    {filterOptions.currencies.map((pair, index) => (
                                        <option key={index} value={pair}>{pair}</option>
                                    ))}
                                </Form.Select>
                            </Form.Group>
                        </Col>
                        <Col sm={6} md={3}>
                            <Form.Group>
                                <Form.Label>Counterparty</Form.Label>
                                <Form.Select 
                                    name="counterparty" 
                                    value={localFilters.counterparty}
                                    onChange={handleInputChange}
                                >
                                    <option value="">All Counterparties</option>
                                    {filterOptions.counterparties.map((cp, index) => (
                                        <option key={index} value={cp}>{cp}</option>
                                    ))}
                                </Form.Select>
                            </Form.Group>
                        </Col>
                        <Col sm={6} md={3}>
                            <Form.Group>
                                <Form.Label>Date Range</Form.Label>
                                <Row className="g-1">
                                    <Col>
                                        <Form.Control 
                                            type="date" 
                                            name="date_from"
                                            value={localFilters.date_from}
                                            onChange={handleInputChange}
                                            placeholder="From"
                                        />
                                    </Col>
                                    <Col>
                                        <Form.Control 
                                            type="date" 
                                            name="date_to"
                                            value={localFilters.date_to}
                                            onChange={handleInputChange}
                                            placeholder="To"
                                        />
                                    </Col>
                                </Row>
                            </Form.Group>
                        </Col>
                    </Row>
                )}
            </Form>
        </div>
    );
};

export default TradingFilters;