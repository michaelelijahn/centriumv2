import React, { useState, useRef } from 'react';
import { Form, Button, InputGroup, Spinner } from 'react-bootstrap';

const CsvUploader = ({ onUpload, uploading }) => {
    const [selectedFile, setSelectedFile] = useState(null);
    const fileInputRef = useRef(null);

    const handleFileChange = (e) => {
        if (e.target.files[0]) {
            setSelectedFile(e.target.files[0]);
        }
    };

    const handleUpload = () => {
        if (selectedFile) {
            onUpload(selectedFile);
            setTimeout(() => {
                setSelectedFile(null);
                if (fileInputRef.current) {
                    fileInputRef.current.value = '';
                }
            }, 1000);
        }
    };

    return (
        <div>
            <h5 className="mb-3">Upload Trades CSV</h5>
            <div className="d-flex align-items-end">
                <InputGroup className="me-3 w-75">
                    <Form.Control
                        type="file"
                        accept=".csv"
                        onChange={handleFileChange}
                        disabled={uploading}
                        ref={fileInputRef}
                    />
                    <Button 
                        variant="primary" 
                        onClick={handleUpload}
                        disabled={!selectedFile || uploading}
                    >
                        {uploading ? (
                            <>
                                <Spinner 
                                    as="span" 
                                    animation="border" 
                                    size="sm" 
                                    className="me-1"
                                />
                                Uploading...
                            </>
                        ) : (
                            <>
                                <i className="mdi mdi-upload me-1"></i>
                                Upload
                            </>
                        )}
                    </Button>
                </InputGroup>
                <div className="ms-2 text-muted small mt-1">
                    Only CSV files are supported. Maximum file size: 10MB.
                </div>
            </div>
            <div className="mt-2 text-muted small">
                <strong>Expected format:</strong> CSV with columns for Trade ID, Timestamp, Book, Currency Pair, Side, Quantity, Price, Counterparty, etc.
            </div>
        </div>
    );
};

export default CsvUploader;