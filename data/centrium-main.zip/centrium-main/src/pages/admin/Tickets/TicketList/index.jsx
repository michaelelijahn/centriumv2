import React, { useState, useEffect } from 'react';
import { Card, Table, Form, InputGroup, Button, Badge, Pagination, Row, Col, Spinner } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { authApi } from '@/common';
import { useNotificationContext } from '@/common';
import { PageBreadcrumb } from '@/components';

const AdminTicketsList = () => {
    const [tickets, setTickets] = useState([]);
    const [loading, setLoading] = useState(true);
    const [pagination, setPagination] = useState({
        page: 1,
        limit: 10,
        total: 0,
        pages: 0
    });
    const [search, setSearch] = useState('');
    const [filters, setFilters] = useState({
        status: '',
        sort_by: 'created_at',
        sort_order: 'desc'
    });
    const { showNotification } = useNotificationContext();

    useEffect(() => {
        fetchTickets();
    }, [pagination.page, filters]);

    const fetchTickets = async () => {
        setLoading(true);
        try {
            const params = {
                page: pagination.page,
                limit: pagination.limit,
                search: search,
                ...filters
            };

            const response = await authApi.getAllTickets(params);
            
            if (response?.data?.tickets) {
                setTickets(response.data.tickets);
                setPagination({
                    ...pagination,
                    total: response.data.pagination.total,
                    pages: response.data.pagination.pages
                });
            }
        } catch (error) {
            showNotification({
                message: `Error fetching tickets: ${error.toString()}`,
                type: 'error'
            });
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = (e) => {
        e.preventDefault();
        setPagination({ ...pagination, page: 1 });
        fetchTickets();
    };

    const clearSearch = () => {
        setSearch('');
        setTimeout(() => {
            setPagination({ ...pagination, page: 1 });
            fetchTickets();
        }, 0);
    };

    const handleStatusChange = (e) => {
        setFilters({ ...filters, status: e.target.value });
        setPagination({ ...pagination, page: 1 });
    };

    const handleSortChange = (column) => {
        if (filters.sort_by === column) {
            setFilters({
                ...filters,
                sort_order: filters.sort_order === 'asc' ? 'desc' : 'asc'
            });
        } else {
            setFilters({
                ...filters,
                sort_by: column,
                sort_order: 'desc'
            });
        }
    };

    const getSortIcon = (column) => {
        if (filters.sort_by !== column) return null;
        
        return filters.sort_order === 'asc' 
            ? <i className="mdi mdi-arrow-up ms-1" />
            : <i className="mdi mdi-arrow-down ms-1" />;
    };

    const handlePageChange = (page) => {
        setPagination({
            ...pagination,
            page
        });
    };

    const getStatusBadge = (status) => {
        switch (status) {
            case 'open':
                return <Badge bg="info">Open</Badge>;
            case 'in_progress':
                return <Badge bg="warning">In Progress</Badge>;
            case 'resolved':
                return <Badge bg="success">Resolved</Badge>;
            case 'closed':
                return <Badge bg="secondary">Closed</Badge>;
            default:
                return <Badge bg="light" text="dark">{status}</Badge>;
        }
    };

    return (
        <>
            <PageBreadcrumb title="Support Tickets" subName="Admin" />
            
            <Card>
                <Card.Header>
                    <div className="d-flex justify-content-between align-items-center flex-wrap">
                        <h4 className="header-title mb-3 mb-sm-0">All Support Tickets</h4>
                        <div className="d-flex">
                            <Form.Select 
                                className="me-2"
                                value={filters.status}
                                onChange={handleStatusChange}
                                style={{ width: '130px' }}
                            >
                                <option value="">All Status</option>
                                <option value="open">Open</option>
                                <option value="in_progress">In Progress</option>
                                <option value="resolved">Resolved</option>
                                <option value="closed">Closed</option>
                            </Form.Select>
                            <Form onSubmit={handleSearch}>
                                <InputGroup>
                                    <Form.Control
                                        placeholder="Search tickets..."
                                        value={search}
                                        onChange={(e) => setSearch(e.target.value)}
                                    />
                                    {search && (
                                        <Button variant="outline-secondary" onClick={clearSearch}>
                                            <i className="mdi mdi-close" />
                                        </Button>
                                    )}
                                    <Button type="submit" variant="primary">
                                        <i className="mdi mdi-magnify" />
                                    </Button>
                                </InputGroup>
                            </Form>
                        </div>
                    </div>
                </Card.Header>
                <Card.Body>
                    {/* Summary Stats */}
                    <Row className="mb-4">
                        <Col md={3} sm={6} className="mb-2 mb-md-0">
                            <Card className="border bg-light mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-primary rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-ticket text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {pagination.total}
                                            </h5>
                                            <p className="text-muted mb-0">Total</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={3} sm={6} className="mb-2 mb-md-0">
                            <Card className="border bg-info bg-opacity-10 mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-info rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-inbox-multiple text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {tickets.filter(t => t.status === 'open').length}
                                            </h5>
                                            <p className="text-muted mb-0">Open</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={3} sm={6} className="mb-2 mb-md-0">
                            <Card className="border bg-warning bg-opacity-10 mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-warning rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-clock text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {tickets.filter(t => t.status === 'in_progress').length}
                                            </h5>
                                            <p className="text-muted mb-0">In Progress</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={3} sm={6}>
                            <Card className="border bg-success bg-opacity-10 mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-success rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-check-all text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {tickets.filter(t => t.status === 'resolved' || t.status === 'closed').length}
                                            </h5>
                                            <p className="text-muted mb-0">Resolved</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>

                    <div className="table-responsive">
                        <Table className="table-centered table-hover mb-0">
                            <thead>
                                <tr>
                                    <th 
                                        onClick={() => handleSortChange('ticket_id')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        ID {getSortIcon('ticket_id')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('subject')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Subject {getSortIcon('subject')}
                                    </th>
                                    <th>
                                        Customer
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('status')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Status {getSortIcon('status')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('created_at')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Created {getSortIcon('created_at')}
                                    </th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {loading ? (
                                    <tr>
                                        <td colSpan="6" className="text-center py-3">
                                            <Spinner animation="border" size="sm" variant="primary" className="me-2" />
                                            Loading tickets...
                                        </td>
                                    </tr>
                                ) : tickets.length === 0 ? (
                                    <tr>
                                        <td colSpan="6" className="text-center py-3">
                                            No tickets found.
                                        </td>
                                    </tr>
                                ) : (
                                    tickets.map((ticket) => (
                                        <tr key={ticket.id}>
                                            <td>#{ticket.id}</td>
                                            <td className="text-truncate" style={{ maxWidth: '250px' }}>
                                                <Link to={`/admin/tickets/${ticket.id}`}>
                                                    {ticket.subject}
                                                </Link>
                                            </td>
                                            <td>
                                                <Link to={`/admin/users/${ticket.customer.id}`}>
                                                    {ticket.customer.name}
                                                </Link>
                                            </td>
                                            <td>{getStatusBadge(ticket.status)}</td>
                                            <td>{ticket.created_at}</td>
                                            <td>
                                                <Link 
                                                    to={`/admin/tickets/${ticket.id}`} 
                                                    className="btn btn-sm btn-primary"
                                                >
                                                    <i className="mdi mdi-eye me-1"></i>
                                                    View
                                                </Link>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </Table>
                    </div>

                    {pagination.pages > 1 && (
                        <div className="d-flex justify-content-center mt-4">
                            <Pagination>
                                <Pagination.First 
                                    disabled={pagination.page === 1}
                                    onClick={() => handlePageChange(1)}
                                />
                                <Pagination.Prev 
                                    disabled={pagination.page === 1}
                                    onClick={() => handlePageChange(pagination.page - 1)}
                                />
                                
                                {[...Array(pagination.pages)].map((_, i) => {
                                    if (
                                        i + 1 === 1 || 
                                        i + 1 === pagination.pages || 
                                        (i + 1 >= pagination.page - 2 && i + 1 <= pagination.page + 2)
                                    ) {
                                        return (
                                            <Pagination.Item
                                                key={i}
                                                active={i + 1 === pagination.page}
                                                onClick={() => handlePageChange(i + 1)}
                                            >
                                                {i + 1}
                                            </Pagination.Item>
                                        );
                                    } else if (
                                        i + 1 === pagination.page - 3 || 
                                        i + 1 === pagination.page + 3
                                    ) {
                                        return <Pagination.Ellipsis key={i} className="disabled" />;
                                    }
                                    
                                    return null;
                                })}
                                
                                <Pagination.Next 
                                    disabled={pagination.page === pagination.pages}
                                    onClick={() => handlePageChange(pagination.page + 1)}
                                />
                                <Pagination.Last 
                                    disabled={pagination.page === pagination.pages}
                                    onClick={() => handlePageChange(pagination.pages)}
                                />
                            </Pagination>
                        </div>
                    )}
                </Card.Body>
            </Card>
        </>
    );
};

export default AdminTicketsList;