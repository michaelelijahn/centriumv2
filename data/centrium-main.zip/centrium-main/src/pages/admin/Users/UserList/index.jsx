import React, { useState, useEffect } from 'react';
import { Card, Table, Form, InputGroup, Button, Badge, Pagination, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { authApi } from '@/common';
import { useNotificationContext } from '@/common';
import { PageBreadcrumb } from '@/components';

const UserList = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [pagination, setPagination] = useState({
        page: 1,
        limit: 10,
        total: 0,
        pages: 0
    });
    const [search, setSearch] = useState('');
    const [filters, setFilters] = useState({
        status: '',
        role: '',
        sort_by: 'created_at',
        sort_order: 'desc'
    });
    const { showNotification } = useNotificationContext();

    useEffect(() => {
        fetchUsers();
    }, [pagination.page, filters]);

    const fetchUsers = async () => {
        setLoading(true);
        try {
            const params = {
                page: pagination.page,
                limit: pagination.limit,
                search: search,
                ...filters
            };

            const response = await authApi.getAllUsers(params);
            
            if (response?.data?.users) {
                setUsers(response.data.users);
                setPagination({
                    ...pagination,
                    total: response.data.pagination.total,
                    pages: response.data.pagination.pages
                });
            }
        } catch (error) {
            showNotification({
                message: `Error fetching users: ${error.toString()}`,
                type: 'error'
            });
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = (e) => {
        e.preventDefault();
        setPagination({ ...pagination, page: 1 });
        fetchUsers();
    };

    const clearSearch = () => {
        setSearch('');
        setTimeout(() => {
            setPagination({ ...pagination, page: 1 });
            fetchUsers();
        }, 0);
    };

    const handleFilterChange = (field, value) => {
        setFilters({ ...filters, [field]: value });
        setPagination({ ...pagination, page: 1 });
    };

    const handleSortChange = (column) => {
        if (filters.sort_by === column) {
            setFilters({
                ...filters,
                sort_order: filters.sort_order === 'asc' ? 'desc' : 'asc'
            });
        } else {
            setFilters({
                ...filters,
                sort_by: column,
                sort_order: 'desc'
            });
        }
    };

    const getSortIcon = (column) => {
        if (filters.sort_by !== column) return null;
        
        return filters.sort_order === 'asc' 
            ? <i className="mdi mdi-arrow-up ms-1" />
            : <i className="mdi mdi-arrow-down ms-1" />;
    };

    const handlePageChange = (page) => {
        setPagination({
            ...pagination,
            page
        });
    };

    const renderStatus = (status) => {
        switch (status) {
            case 'active':
                return <Badge bg="success">Active</Badge>;
            case 'inactive':
                return <Badge bg="warning">Inactive</Badge>;
            case 'suspended':
                return <Badge bg="danger">Suspended</Badge>;
            default:
                return <Badge bg="secondary">{status}</Badge>;
        }
    };

    const renderRole = (role) => {
        return role === 'admin' 
            ? <Badge bg="info">Admin</Badge>
            : <Badge bg="secondary">Customer</Badge>;
    };

    return (
        <>
            <PageBreadcrumb title="User Management" subName="Admin" />
            
            <Card>
                <Card.Header>
                    <div className="d-flex justify-content-between align-items-center flex-wrap">
                        <h4 className="header-title mb-3 mb-sm-0">All Users</h4>
                        <div className="d-flex flex-wrap">
                            <Form.Select 
                                className="me-2 mb-2 mb-sm-0"
                                value={filters.status}
                                onChange={(e) => handleFilterChange('status', e.target.value)}
                                style={{ width: '140px' }}
                            >
                                <option value="">All Status</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="suspended">Suspended</option>
                            </Form.Select>
                            <Form.Select 
                                className="me-2 mb-2 mb-sm-0"
                                value={filters.role}
                                onChange={(e) => handleFilterChange('role', e.target.value)}
                                style={{ width: '140px' }}
                            >
                                <option value="">All Roles</option>
                                <option value="admin">Admin</option>
                                <option value="customer">Customer</option>
                            </Form.Select>
                            <Form onSubmit={handleSearch} className="mb-2 mb-sm-0">
                                <InputGroup>
                                    <Form.Control
                                        placeholder="Search by name, email, ID..."
                                        value={search}
                                        onChange={(e) => setSearch(e.target.value)}
                                    />
                                    {search && (
                                        <Button variant="outline-secondary" onClick={clearSearch}>
                                            <i className="mdi mdi-close" />
                                        </Button>
                                    )}
                                    <Button type="submit" variant="primary">
                                        <i className="mdi mdi-magnify" />
                                    </Button>
                                </InputGroup>
                            </Form>
                        </div>
                    </div>
                </Card.Header>
                <Card.Body>
                    <Row className="mb-4">
                        <Col md={3} sm={6} className="mb-2 mb-md-0">
                            <Card className="border bg-light mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-primary rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-account-multiple text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {pagination.total}
                                            </h5>
                                            <p className="text-muted mb-0">Total Users</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={3} sm={6} className="mb-2 mb-md-0">
                            <Card className="border bg-success bg-opacity-10 mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-success rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-account-check text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {users.filter(u => u.status === 'active').length}
                                            </h5>
                                            <p className="text-muted mb-0">Active Users</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={3} sm={6} className="mb-2 mb-md-0">
                            <Card className="border bg-info bg-opacity-10 mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-info rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-shield-account text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {users.filter(u => u.role === 'admin').length}
                                            </h5>
                                            <p className="text-muted mb-0">Administrators</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={3} sm={6}>
                            <Card className="border bg-warning bg-opacity-10 mb-0">
                                <Card.Body className="py-2">
                                    <div className="d-flex align-items-center">
                                        <div className="avatar-sm bg-warning rounded me-2 d-flex align-items-center justify-content-center">
                                            <i className="mdi mdi-account-alert text-white"></i>
                                        </div>
                                        <div>
                                            <h5 className="mb-0">
                                                {users.filter(u => u.status !== 'active').length}
                                            </h5>
                                            <p className="text-muted mb-0">Inactive Users</p>
                                        </div>
                                    </div>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>

                    <div className="table-responsive">
                        <Table className="table-centered table-hover mb-0">
                            <thead>
                                <tr>
                                    <th 
                                        onClick={() => handleSortChange('user_id')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        ID {getSortIcon('user_id')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('name')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Name {getSortIcon('name')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('email')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Email {getSortIcon('email')}
                                    </th>
                                    <th>Role</th>
                                    <th 
                                        onClick={() => handleSortChange('created_at')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Registered {getSortIcon('created_at')}
                                    </th>
                                    <th 
                                        onClick={() => handleSortChange('status')}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        Status {getSortIcon('status')}
                                    </th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {loading ? (
                                    <tr>
                                        <td colSpan="7" className="text-center py-3">
                                            <div className="spinner-border spinner-border-sm text-primary me-2" />
                                            Loading users...
                                        </td>
                                    </tr>
                                ) : users.length === 0 ? (
                                    <tr>
                                        <td colSpan="7" className="text-center py-3">
                                            No users found.
                                        </td>
                                    </tr>
                                ) : (
                                    users.map((user) => (
                                        <tr key={user.id}>
                                            <td>{user.id}</td>
                                            <td>
                                                <Link to={`/admin/users/${user.id}`} className="text-body fw-medium">
                                                    {user.name}
                                                </Link>
                                            </td>
                                            <td>{user.email}</td>
                                            <td>{renderRole(user.role)}</td>
                                            <td>{user.created_at}</td>
                                            <td>{renderStatus(user.status)}</td>
                                            <td>
                                                <Link 
                                                    to={`/admin/users/${user.id}`} 
                                                    className="btn btn-sm btn-primary me-1"
                                                >
                                                    <i className="mdi mdi-account-details me-1" />
                                                    Details
                                                </Link>
                                                <Link 
                                                    to={`/admin/users/${user.id}/tickets`} 
                                                    className="btn btn-sm btn-info"
                                                >
                                                    <i className="mdi mdi-ticket me-1" />
                                                    Tickets
                                                </Link>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </Table>
                    </div>

                    {pagination.pages > 1 && (
                        <div className="d-flex justify-content-center mt-4">
                            <Pagination>
                                <Pagination.First 
                                    disabled={pagination.page === 1}
                                    onClick={() => handlePageChange(1)}
                                />
                                <Pagination.Prev 
                                    disabled={pagination.page === 1}
                                    onClick={() => handlePageChange(pagination.page - 1)}
                                />
                                
                                {[...Array(pagination.pages)].map((_, i) => {
                                    if (
                                        i + 1 === 1 || 
                                        i + 1 === pagination.pages || 
                                        (i + 1 >= pagination.page - 2 && i + 1 <= pagination.page + 2)
                                    ) {
                                        return (
                                            <Pagination.Item
                                                key={i}
                                                active={i + 1 === pagination.page}
                                                onClick={() => handlePageChange(i + 1)}
                                            >
                                                {i + 1}
                                            </Pagination.Item>
                                        );
                                    } else if (
                                        i + 1 === pagination.page - 3 || 
                                        i + 1 === pagination.page + 3
                                    ) {
                                        return <Pagination.Ellipsis key={i} className="disabled" />;
                                    }
                                    
                                    return null;
                                })}
                                
                                <Pagination.Next 
                                    disabled={pagination.page === pagination.pages}
                                    onClick={() => handlePageChange(pagination.page + 1)}
                                />
                                <Pagination.Last 
                                    disabled={pagination.page === pagination.pages}
                                    onClick={() => handlePageChange(pagination.pages)}
                                />
                            </Pagination>
                        </div>
                    )}
                </Card.Body>
            </Card>
        </>
    );
};

export default UserList;