import React, { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import AdminRouteWrapper from '@/components/AdminRouteWrapper';
import { PageLoader } from '@/components';

const AdminDashboard = lazy(() => import('@/pages/dashboard/Admin'));
const AdminTicketsList = lazy(() => import('@/pages/admin/Tickets/TicketList'));
const UserList = lazy(() => import('@/pages/admin/Users/UserList'));
const UserDetails = lazy(() => import('@/pages/admin/Users/UserDetails'));
const UserTickets = lazy(() => import('@/pages/admin/Users/UserTickets'));
const TicketDetail = lazy(() => import('@/components/Ticket/TicketDetail'));
const TradingList = lazy(() => import('@/pages/admin/Trading/TradingList'));
const TradeDetail = lazy(() => import('@/pages/admin/Trading/TradeDetail'));

const AdminRoutes = () => {
    return (
        <Suspense fallback={<PageLoader />}>
            <Routes>
                <Route path="/" element={
                    <AdminRouteWrapper>
                        <AdminDashboard />
                    </AdminRouteWrapper>
                } />
                <Route path="/tickets" element={
                    <AdminRouteWrapper>
                        <AdminTicketsList />
                    </AdminRouteWrapper>
                } />
                <Route path="/tickets/:ticketId" element={
                    <AdminRouteWrapper>
                        <TicketDetail adminView={true} />
                    </AdminRouteWrapper>
                } />
                <Route path="/users" element={
                    <AdminRouteWrapper>
                        <UserList />
                    </AdminRouteWrapper>
                } />
                <Route path="/users/:userId" element={
                    <AdminRouteWrapper>
                        <UserDetails />
                    </AdminRouteWrapper>
                } />
                <Route path="/users/:userId/tickets" element={
                    <AdminRouteWrapper>
                        <UserTickets />
                    </AdminRouteWrapper>
                } />
                
                {/* Trading routes */}
                <Route path="/trading" element={
                    <AdminRouteWrapper>
                        <TradingList />
                    </AdminRouteWrapper>
                } />
                <Route path="/trading/details/:tradeId" element={
                    <AdminRouteWrapper>
                        <TradeDetail />
                    </AdminRouteWrapper>
                } />
            </Routes>
        </Suspense>
    );
};

export default AdminRoutes;